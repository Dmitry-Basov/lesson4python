def max1(a, b):
    if a > b:
        return a
    return b
